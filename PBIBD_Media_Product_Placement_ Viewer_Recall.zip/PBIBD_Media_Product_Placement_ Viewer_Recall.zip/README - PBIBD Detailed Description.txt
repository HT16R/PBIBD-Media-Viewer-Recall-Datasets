

                                                                           PBIBD – Brand Placement Viewer Recall Scores 


 - Dataset collection for Chapter - 'Research Designs' of an academic book on Quantitative Media Research, focused on the Global South, but with global applicability. 
 - Demonstrates adapting a BIBD to a 3 × 3 rectangular 2-associate class PBIBD (Example 39 of the academic book) where full/strict pair-wise balance is impractical (e.g., narrative-driven product placements).

A) Context & Design

   • Nine fictional brands (treatments T1–T9) embedded in 12 episodes (blocks) of a Netflix-style series about urban professionals.  
   • Each episode features k=3 brands. Partial balance reflects conceptual similarity:same-category pairs co-occur more (λ₁=2) for synergy, cross categories less so (λ₂=1), for variety—mirroring real scheduling (e.g., tech brands in gadget-heavy plots).

B) Brands & Categories (3 groups of 3 for n₁=2 symmetry):

   • Consumables [Group 1]: T1-Peppy (sports drink), T2-CoacaBeanscaffe (coffee chain), T3-Bungee-Bar (energy bar).
   → 1st associates: e.g., Peppy pairs twice with CoacaBeanscaffe/Bungee-Bar.

   • Tech [Group 2]: T4-Beta-Nex (smartphone), T5-Solstice (laptop), T6-Beats-In (streaming music app).
   → 1st associates: e.g., Beta-Nex pairs twice with Solstice/Beats-In.

   • Lifestyle/Entertainment [Group 3]: T7-Cine-BigTime (movie ticket platform), T8-Destination-X (ride-hailing app), T9-Feather-Light (footwear).
   → 1st associates: e.g., Feather-Light pairs twice with Cine-BigTime/Destination-X (post-flick rides in comfortable shoes).

C) PBIBD Parameters:

   • v=9 (treatments/brands)
   • b=12 (blocks/episodes)
   • k=3 (brands per episode)
   • r=4 (each brand in 4 episodes, across the full 12 episode series)
   • λ₁=2 (intra-group pairs co-occur twice)
   • λ₂=1 (inter-group pairs co-occur once)
   • Associate classes: m=2, n₁=2 (first associates), n₂=6 (second associates)

   → Recall measured on 1–10 Graphic Rating Scale (GRS) by viewers stratified by demographics (for instance, by age, gender, media consumption habits).
   → Simulated heterogeneity across strata mimics real variability (for instance, higher recall for tech among young users).

D) Files Included

a) PBIBD_Viewer_Recall.xlsx  

   • 360 rows: Drawn from 2 replications (R1 & R2 i.e., theoretical 432 rows/observations), but deliberately capped at the same size as the BIBD dataset (Example 38) for direct pedagogical comparison. 
     A complete single replication with 6 viewers yields 216 rows; the file is extended but truncated to exactly 360 for parity.
   • Columns: Respondent_ID (e.g., R1_V1), Replication (R1), Episode (1–12), Brand (T1–T9 or full name), Category (Consumables/Tech/Lifestyle), Recall_Score (1–10).  
   • Use: Raw data for initial PBIBD exploration.

b) PBIBD_Viewer_Recall_4Reps.xlsx  

   • 360 rows: Subsampled from 4-replication setup (theoretical 864 rows).  
   • Adds Replication column (R1–R4: e.g., R1=young urban, R2=older professionals, R3=heavy streamers, R4=mixed gender).  
   • Same structure; enables strata effects analysis (e.g., ANOVA on replication × brand).

c) PBIBD_Viewer_Recall_4Reps_28_Sample.xlsx 
 
   • 28-row random excerpt across all 4 replications.
   • Quick preview: Shows respondent_ID, Viewer_Recall_Score, and Replications.
   • Subsampling still preserves PBIBD structure (brand placements + associate pairings).

   → Note on Dataset Sizes: Although the manuscript describes a design with five demographic strata/replications (n=30 viewers; theoretical 1,080 observations), the first two datasets are intentionally standardised to exactly 360 rows/observations. 
     This allows readers to view the BIBD (Ex.38) and PBIBD (Ex.39) files together and immediately compare full pair-wise balance with partial pair-wise balance, without any distraction due to differing row counts. 

E) Book Usage

   • Referenced in Example 39 & Tables 26.1 to 26.4(b). 
   • License: MIT (attribute, share, adapt freely).  

