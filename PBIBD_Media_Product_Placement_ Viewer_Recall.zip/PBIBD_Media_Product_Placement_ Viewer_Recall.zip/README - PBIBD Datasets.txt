                                                                                                              Datasets


 - This deposit contains three Excel workbooks accompanying Chapter 4 (Research Designs) of a forthcoming academic book on Quantitative Media Research with a focus on the Global South, but with Global applicability.
 - The files illustrate a 2-associate class Partially Balanced Incomplete Block Design (PBIBD) for viewer recall of nine fictional branded products (T1–T9) across 12 episodes of a streaming series, grouped by category for realistic partial balance.

A) Brands & Categories:

   • Consumables: T1=Peppy (sports drink), T2=CoacaBeanscaffe (coffee chain), T3=Bungee-Bar (energy bar)
   • Tech: T4=Beta-Nex (smartphone), T5=Solstice (laptop), T6=Beats-In (streaming music app)
   • Lifestyle/Entertainment: T7=Cine-BigTime (movie ticket platform), T8=Destination-X (ride-hailing app), T9=Feather-Light (footwear)

   • 1st Associates (λ₁=2): Intra-category pairs (e.g., Peppy with CoacaBeanscaffe/Bungee-Bar).  
   • 2nd Associates (λ₂=1): Cross-category pairs (e.g., Feather-Light with Peppy/Beats-In/etc.).

B) Files

   a) PBIBD_Viewer_Recall.xlsx → 360 observations, single replication (truncated for BIBD comparison).

   -> Columns:
 
    • Respondent_ID
    • Block (Episodes)
    • Treatments (Branded Products)
    • Viewer_Recall_Score
     
   b) PBIBD_Viewer_Recall_4Reps.xlsx → 360 observations sub-sampled from all 4 replications (theoretical 864 rows), with Replication column (R1–R4).

   -> Columns:

    • Respondent_ID
    • Block (Episodes)
    • Treatments (Branded Products)
    • Viewer_Recall_Score
    • Replication


   c) PBIBD_Viewer_Recall_4Reps_28_Sample.xlsx → Random 28-row excerpt across all 4 replications.

   -> Columns:
 
    • Respondent_ID
    • Block (Episodes)
    • Treatments (Branded Products)
    • Viewer_Recall_Score
    • Replication

 - All simulated in R, adhering to PBIBD(v=9, b=12, k=3, r=4, λ₁=2, λ₂=1). 
 - Columns: Respondent_ID, Block (Episodes), Treatments (Branded Products), Viewer_Recall_Score (1–10 GRS) and Replication.
